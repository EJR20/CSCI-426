<?php
require_once 'config/db.php';
echo "DB connection works!";
