<?php
// includes/footer.php
?>
</main>
<footer style="text-align:center;font-size:0.8rem;padding:10px;">
    © <?php echo date('Y'); ?> FitQuest
</footer>
</body>
</html>
